
# RIDOY-XD
[![Typing SVG](https://readme-typing-svg.demolab.com?font=Fira+Code&pause=1000&width=435&lines=VERSION++%E2%91%86+8.0.1+PAID%F0%9F%94%A5;%F0%9F%92%9C%F0%9F%94%A5HATERS+FILL+ME+OKY+DON'T+SAD%F0%9F%94%A5;RMX+BRAND)](https://git.io/typing-svg)


 - `pkg update -y`
 - `pkg upgrade -y`
- `pkg install python`
- `pkg install python2`
- `pkg install python3`
- `pip install rich`
- `pip install requests`
- `pip2 install requests`
- `pip install mechanize`
- `pip2 install mechanize`
- `pip install lolcat`
- `pip install bs4`
- `pip2 install bs4`
- `pip install futures`
- `pip2 install futures`
- `pkg install git`

- `💚Run Tool 💦`

-  `rm -rf RIDOY-XD `
- `git clone https://github.com/RIDOY-404-CYBER/RIDOY-XD `
- `git pull `
- `cd RIDOY-XD `
- `python RIDOY.py `
